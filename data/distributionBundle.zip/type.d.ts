/// <reference types="node" />
/// <reference types="webpack-env" />
/// <reference types="node" />
/// <reference types="node" />
import { Matchers } from 'expect';
import { Dirent as DirectoryEntry, Stats as FileStats } from 'fs';
import Tools, { BoundTools } from './index';
import { DefinedSymbol, ThrowSymbol, UndefinedSymbol } from './testHelper';
export declare type AnyFunction = (..._parameters: Array<any>) => any;
export declare type Unpacked<T> = T extends (infer U)[] ? U : T extends (..._parameters: Array<unknown>) => infer U ? U : T extends Promise<infer U> ? U : T;
export declare type FirstParameter<FunctionType extends AnyFunction> = Parameters<FunctionType>[0];
export declare type SecondParameter<FunctionType extends AnyFunction> = Parameters<FunctionType>[1];
export declare type ThirdParameter<FunctionType extends AnyFunction> = Parameters<FunctionType>[2];
export declare type ParametersExceptFirst<FunctionType> = FunctionType extends (_parameter: any, ..._additionalParameters: infer AdditionalParameters) => any ? AdditionalParameters : [
];
export declare type FunctionTestTuple<FunctionType extends AnyFunction> = [
    ReturnType<FunctionType>,
    ...Parameters<FunctionType>
];
export declare type FunctionTestPromiseTuple<FunctionType extends AnyFunction> = [
    ThenParameter<ReturnType<FunctionType>>,
    ...Parameters<FunctionType>
];
export declare type FunctionTestPromiseRejectionTuple<FunctionType extends AnyFunction> = [Error, ...Parameters<FunctionType>];
export declare type BaseSelector<T = unknown, E = unknown> = number | string | ((_target: T) => E);
export declare type Selector<T = unknown, E = unknown> = Array<BaseSelector<T, E>> | BaseSelector<T, E>;
export declare type TestSymbol = typeof DefinedSymbol | typeof ThrowSymbol | typeof UndefinedSymbol;
export declare type ThenParameter<Type> = Type extends PromiseLike<infer U> ? U : Type;
export declare type ThenParameterRecursive<Type> = Type extends PromiseLike<infer U> ? ThenParameterRecursive<U> : Type;
export declare type ValueOf<Type> = Type[keyof Type];
export declare type RecursiveNonNullable<Type> = {
    [Property in keyof Type]: Type[Property] extends (infer OtherType)[] ? RecursiveNonNullable<OtherType>[] : Type[Property] extends AnyFunction ? NonNullable<Type[Property]> : Type[Property] extends Mapping<unknown> ? RecursiveNonNullable<Type[Property]> : NonNullable<Type[Property]>;
};
export declare type RecursivePartial<Type> = Partial<Type> | {
    [Property in keyof Type]?: Type[Property] extends (infer OtherType)[] ? RecursivePartial<OtherType>[] : Type[Property] extends AnyFunction ? Partial<Type[Property]> : Type[Property] extends Mapping<unknown> ? RecursivePartial<Type[Property]> : Partial<Type[Property]>;
};
export declare type FileTraversionResult = false | null | Promise<false | null | void> | void;
export declare type TestMatchers<T extends void> = Matchers<T> & {
    not: Matchers<T>;
};
export declare type ImportFunction = (_id: string) => Promise<ReturnType<typeof require>>;
export declare type HTMLItem = Comment | Document | HTMLElement | Text;
export declare type Primitive = boolean | null | number | string | undefined;
export declare type PlainObject<Type = Primitive> = {
    [key: string]: Array<PlainObject<Type> | Type> | PlainObject<Type> | Type;
};
export interface ProxyHandler<T = unknown> {
    deleteProperty: (_target: T, _key: string | symbol) => boolean;
    get: (_target: T, _key: string | symbol) => unknown;
    has: (_target: T, _key: string | symbol) => boolean;
    set: (_target: T, _key: string | symbol, _value: unknown) => boolean;
}
export declare type ProxyType<T = unknown> = T & {
    __revoke__?: () => void;
    __target__: T;
};
export interface CookieOptions {
    domain: string;
    httpOnly: boolean;
    minimal: boolean;
    numberOfDaysUntilExpiration: number;
    path: string;
    sameSite: 'Lax' | 'None' | 'Strict' | '';
    secure: boolean;
}
export declare type UnknownFunction = (..._parameters: Array<unknown>) => unknown;
export declare type ArrayTransformer<T = unknown, R = unknown, P = unknown> = (_data: Array<T>, ..._additionalParameter: Array<P>) => Array<R>;
export declare type SynchronousProcedureFunction = (..._parameters: Array<unknown>) => void;
export declare type AsynchronousProcedureFunction = (..._parameters: Array<unknown>) => Promise<void>;
export declare type ProcedureFunction = AsynchronousProcedureFunction | SynchronousProcedureFunction;
export declare type GetterFunction = (_keyOrValue: unknown, _key: string | symbol, _target: unknown) => unknown;
export declare type SetterFunction = (_key: string | symbol, _value: unknown, _target: unknown) => unknown;
export interface CheckReachabilityOptions {
    expectedIntermediateStatusCodes: Array<number> | number;
    options: RequestInit;
    pollIntervallInSeconds: number;
    statusCodes: Array<number> | number;
    timeoutInSeconds: number;
    wait: boolean;
}
export interface CompareOptions {
    compareBlobs: boolean;
    deep: number;
    exceptionPrefixes: Array<string>;
    ignoreFunctions: boolean;
    properties: Array<string> | null;
    returnReasonIfNotEqual: boolean;
}
export declare type Encoding = 'ascii' | 'base64' | 'binary' | 'hex' | 'latin1' | 'ucs2' | 'ucs-2' | 'utf8' | 'utf16le' | 'utf-8';
export interface File {
    directoryPath: string;
    directoryEntry: DirectoryEntry | null;
    error: Error | null;
    name: string;
    path: string;
    stats: FileStats | null;
}
export interface ProcessError extends Error {
    parameters: Array<unknown>;
    returnCode: number;
}
export declare type QueryParameters = Array<Array<string> | string> & Mapping<Array<string> | string>;
export interface TimeoutPromise extends Promise<boolean> {
    clear: () => void;
    timeoutID: NodeJS.Timeout;
}
export declare type Mapping<T = string> = {
    [key: string]: T;
};
export declare type ObjectMask = boolean | {
    [key: string]: boolean | ObjectMask;
};
export interface ObjectMaskConfiguration {
    exclude?: ObjectMask;
    include?: ObjectMask;
}
export declare type Evaluateable = {
    __evaluate__: string;
} | {
    __execute__: string;
};
export declare type RecursiveEvaluateable<Type> = Evaluateable | {
    [Property in keyof Type]: (Evaluateable | (Type[Property] extends (infer OtherType)[] ? RecursiveEvaluateable<OtherType>[] : Type[Property] extends Mapping<unknown> ? RecursiveEvaluateable<Type[Property]> : Evaluateable | Type[Property]));
};
export interface PaginateOptions {
    boundaryCount: number;
    disabled: boolean;
    hideNextButton: boolean;
    hidePrevButton: boolean;
    page: number;
    pageSize?: null | number;
    showFirstButton: boolean;
    showLastButton: boolean;
    siblingCount: number;
    total: number;
}
export interface Page {
    disabled: boolean;
    page?: number;
    selected: boolean;
    type: PageType;
}
export declare type PageType = 'end-ellipsis' | 'first' | 'last' | 'next' | 'page' | 'previous' | 'start-ellipsis';
export interface Offset {
    left: number;
    top: number;
}
export interface Position extends Offset {
    bottom: number;
    right: number;
}
export declare type ProcessHandler = (_returnCode: unknown, ..._parameters: Array<unknown>) => void;
export interface ProcessCloseReason {
    parameters: Array<unknown>;
    reason: unknown;
}
export declare type ProcessCloseCallback = (_reason: ProcessCloseReason) => void;
export declare type ProcessErrorCallback = (_reason: ProcessError) => void;
export declare type RelativePosition = 'above' | 'below' | 'in' | 'left' | 'right';
export declare type TemplateFunction<Type = string> = (..._parameters: Array<unknown>) => Type;
export interface CompilationResult<Type = string> {
    error: null | string;
    originalScopeNames: Array<string>;
    scopeNameMapping: Mapping<string>;
    scopeNames: Array<string>;
    templateFunction: TemplateFunction<Type>;
}
export interface EvaluationResult<Type = string> {
    compileError: null | string;
    error: null | string;
    result: Type;
    runtimeError: null | string;
}
export declare type LockCallbackFunction<Type = string> = (_description: string) => Promise<Type> | Type;
export declare type DomNodes<Type = string> = Mapping<Type> & {
    hideJavaScriptEnabled: Type;
    parent?: Type;
    showJavaScriptEnabled: Type;
    window?: Type;
};
export declare type $DomNodes<TElement = HTMLElement> = DomNodes<$T<TElement>>;
export interface Options<Type = string> {
    domNodes: DomNodes<Type>;
    domNodeSelectorInfix: null | string;
    domNodeSelectorPrefix: string;
    logging: boolean;
    name: string;
}
export declare type $TStatic = JQueryStatic;
export declare type $T<TElement = HTMLElement> = JQuery<TElement>;
export interface $Global extends Window {
    Babel?: {
        transform: (_code: string, _configuration: PlainObject) => {
            code: string;
        };
    };
    console: Console;
    dataLayer: Array<PlainObject>;
    $: $TStatic;
}
export interface ToolsFunction<TElement = HTMLElement> {
    class: typeof Tools;
    (..._parameters: Array<unknown>): Tools<TElement>;
}
export interface BoundToolsFunction<TElement = HTMLElement> {
    (_methodName: 'normalizedClassNames'): BoundTools<TElement>;
    (_methodName: 'normalizedStyles'): BoundTools<TElement>;
    (_methodName: 'removeDirective', _directiveName: string): $T<TElement>;
    (_methodName: 'style'): Mapping<number | string>;
    (_methodName: 'text'): string;
    (..._parameters: Array<unknown>): BoundTools<TElement>;
}
declare global {
    interface JQuery<TElement = HTMLElement> {
        Tools: BoundToolsFunction<TElement>;
    }
    interface JQueryStatic {
        document?: Document;
        global: $Global;
        location?: Location;
        Tools: ToolsFunction;
    }
}
export interface StringMarkOptions {
    marker: ((foundWord: string, markedTarget: Array<unknown>) => unknown) | string;
    normalizer: (value: unknown) => string;
    skipTagDelimitedParts: null | [string, string];
}
