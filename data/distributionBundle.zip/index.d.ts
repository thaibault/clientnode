/// <reference types="node" />
/// <reference types="webpack-env" />
/// <reference types="node" />
import { ChildProcess } from 'child_process';
import { AnyFunction, CookieOptions, CheckReachabilityOptions, CompareOptions, CompilationResult, Encoding, EvaluationResult, File, FileTraversionResult, FirstParameter, GetterFunction, ImportFunction, LockCallbackFunction, Mapping, ObjectMaskConfiguration, Options, Page, PaginateOptions, ParametersExceptFirst, PlainObject, ProcessCloseCallback, ProcessErrorCallback, ProcessHandler, ProxyHandler, ProxyType, QueryParameters, RecursiveEvaluateable, RecursivePartial, RelativePosition, SecondParameter, Selector, SetterFunction, StringMarkOptions, TimeoutPromise, UnknownFunction, $DomNodes, $Global, $T, $TStatic } from './type';
export declare const CloseEventNames: readonly ["close", "exit", "SIGINT", "SIGTERM", "SIGQUIT", "uncaughtException"];
export declare const ConsoleOutputMethods: readonly ["debug", "error", "info", "log", "warn"];
export declare const ValueCopySymbol: unique symbol;
export declare const IgnoreNullAndUndefinedSymbol: unique symbol;
export declare const determineGlobalContext: (() => $Global);
export declare let globalContext: $Global;
export declare const setGlobalContext: (context: $Global) => void;
export declare const currentRequire: null | typeof require;
export declare const currentImport: null | ImportFunction;
export declare const optionalRequire: <T = unknown>(id: string) => T | null;
export declare const determine$: (() => $TStatic);
export declare let $: $TStatic;
/**
 * Represents the lock state.
 * @property locks - Mapping of lock descriptions to there corresponding
 * callbacks.
 */
export declare class Lock<Type = string | void> {
    locks: Mapping<Array<LockCallbackFunction<Type>>>;
    /**
     * Initializes locks.
     * @param locks - Mapping of a lock description to callbacks for calling
     * when given lock should be released.
     *
     * @returns Nothing.
     */
    constructor(locks?: Mapping<Array<LockCallbackFunction<Type>>>);
    /**
     * Calling this method introduces a starting point for a critical area with
     * potential race conditions. The area will be binded to given description
     * string. So don't use same names for different areas.
     * @param description - A short string describing the critical areas
     * properties.
     * @param callback - A procedure which should only be executed if the
     * interpreter isn't in the given critical area. The lock description
     * string will be given to the callback function.
     * @param autoRelease - Release the lock after execution of given callback.
     *
     * @returns Returns a promise which will be resolved after releasing lock.
     */
    acquire(description: string, callback?: LockCallbackFunction<Type>, autoRelease?: boolean): Promise<Type>;
    /**
     * Calling this method  causes the given critical area to be finished and
     * all functions given to "acquire()" will be executed in right order.
     * @param description - A short string describing the critical areas
     * properties.
     *
     * @returns Returns the return (maybe promise resolved) value of the
     * callback given to the "acquire" method.
     */
    release(description: string): Promise<Type | void>;
}
/**
 * Represents the semaphore state.
 * @property queue - List of waiting resource requests.
 *
 * @property numberOfFreeResources - Number free allowed concurrent resource
 * uses.
 * @property numberOfResources - Number of allowed concurrent resource uses.
 */
export declare class Semaphore {
    queue: Array<AnyFunction>;
    numberOfResources: number;
    numberOfFreeResources: number;
    /**
     * Initializes number of resources.
     * @param numberOfResources - Number of resources to manage.
     * @returns Nothing.
     */
    constructor(numberOfResources?: number);
    /**
     * Acquires a new resource and runs given callback if available.
     * @returns A promise which will be resolved if requested resource is
     * available.
     */
    acquire(): Promise<number>;
    /**
     * Releases a resource and runs a waiting resolver if there exists some.
     * @returns Nothing.
     */
    release(): void;
}
/**
 * This plugin provides such interface logic like generic controller logic for
 * integrating plugins into $, mutual exclusion for depending gui elements,
 * logging additional string, array or function handling. A set of helper
 * functions to parse  option objects dom trees or handle events is also
 * provided.
 * @property static:abbreviations - Lists all known abbreviation for proper
 * camel case to delimited and back conversion.
 * @property static:animationEndEventNames - Saves a string with all css3
 * browser specific animation end event names.
 * @property static:classToTypeMapping - String representation to object type
 * name mapping.
 * @property static:keyCode - Saves a mapping from key codes to their
 * corresponding name.
 * @property static:maximalSupportedInternetExplorerVersion - Saves currently
 * maximal supported internet explorer version. Saves zero if no internet
 * explorer present.
 * @property static:name - Not minifyable class name.
 * @property static:noop - A no-op dummy function.
 * @property static:specialRegexSequences - A list of special regular
 * expression symbols.
 * @property static:transitionEndEventNames - Saves a string with all css3
 * browser specific transition end event names.
 *
 * @property static:_dateTimePatternCache - Caches compiled date tine pattern
 * regular expressions.
 *
 * @property static:_defaultOptions - Fallback options if not overwritten by
 * the options given to the constructor method.
 * @property static:_defaultOptions.logging {boolean} - Indicates whether
 * logging should be active.
 * @property static:_defaultOptions.domNodeSelectorInfix {string} - Selector
 * infix for all needed dom nodes.
 * @property static:_defaultOptions.domNodeSelectorPrefix {string} - Selector
 * prefix for all needed dom nodes.
 * @property static:_defaultOptions.domNodes {Object.<string, string>} -
 * Mapping of names to needed dom nodes referenced by there selector.
 * @property static:_defaultOptions.domNodes.hideJavaScriptEnabled {string} -
 * Selector to dom nodes which should be hidden if javaScript is available.
 * @property static:_defaultOptions.domNodes.showJavaScriptEnabled {string} -
 * Selector to dom nodes which should be visible if javaScript is available.
 *
 * @property static:_javaScriptDependentContentHandled - Indicates whether
 * javaScript dependent content where hide or shown.
 *
 * @property $domNode - $-extended dom node if one was given to the constructor
 * method.
 *
 * @property options - Options given to the constructor.
 */
export declare class Tools<TElement = HTMLElement> {
    static abbreviations: Array<string>;
    static readonly animationEndEventNames = "animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd";
    static readonly classToTypeMapping: Mapping;
    static readonly keyCode: Mapping<number>;
    static locales: Array<string>;
    static readonly maximalSupportedInternetExplorerVersion: number;
    static noop: AnyFunction;
    static plainObjectPrototypes: Array<FirstParameter<typeof Object.getPrototypeOf>>;
    static readonly specialRegexSequences: Array<string>;
    static readonly transitionEndEventNames = "transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd";
    static _dateTimePatternCache: Array<RegExp>;
    static _defaultOptions: Partial<Options>;
    static _javaScriptDependentContentHandled: boolean;
    $domNode: null | $T<TElement>;
    options: Options;
    /**
     * Triggered if current object is created via the "new" keyword. The dom
     * node selector prefix enforces to not globally select any dom nodes which
     * aren't in the expected scope of this plugin. "{1}" will be automatically
     * replaced with this plugin name suffix ("tools"). You don't have to use
     * "{1}" but it can help you to write code which is more reconcilable with
     * the dry concept.
     * @param $domNode - $-extended dom node to use as reference in various
     * methods.
     *
     * @returns Nothing.
     */
    constructor($domNode?: $T<TElement>);
    /**
     * This method could be overwritten normally. It acts like a destructor.
     * @returns Returns the current instance.
     */
    destructor(): this;
    /**
     * This method should be overwritten normally. It is triggered if current
     * object was created via the "new" keyword and is called now.
     * @param options - An options object.
     *
     * @returns Returns the current instance.
     */
    initialize<R = this>(options?: RecursivePartial<Options>): R;
    /**
     * Defines a generic controller for dom node aware plugins.
     * @param object - The object or class to control. If "object" is a class
     * an instance will be generated.
     * @param parameters - The initially given arguments object.
     * @param $domNode - Optionally a $-extended dom node to use as reference.
     *
     * @returns Returns whatever the initializer method returns.
     */
    static controller<TElement = HTMLElement>(this: void, object: unknown, parameters: unknown, $domNode?: null | $T<TElement>): unknown;
    /**
     * Formats given date or current via given format specification.
     * @param format - Format specification.
     * @param dateTime - Date time to format.
     * @param options - Additional configuration options for
     *                  "Intl.DateTimeFormat".
     * @param locales - Locale or list of locales to use for formatting. First
     *                  one take precedence of latter ones.
     *
     * @returns Formatted date time string.
     */
    static dateTimeFormat(this: void, format?: string, dateTime?: Date | number | string, options?: SecondParameter<typeof Intl.DateTimeFormat>, locales?: Array<string> | string): string;
    /**
     * Determines whether its argument represents a JavaScript number.
     * @param value - Value to analyze.
     *
     * @returns A boolean value indicating whether given object is numeric
     * like.
     */
    static isNumeric(this: void, value: unknown): value is number;
    /**
     * Determine whether the argument is a window.
     * @param value - Value to check for.
     *
     * @returns Boolean value indicating the result.
     */
    static isWindow(this: void, value: unknown): value is Window;
    /**
     * Checks if given object is similar to an array and can be handled like an
     * array.
     * @param object - Object to check behavior for.
     *
     * @returns A boolean value indicating whether given object is array like.
     */
    static isArrayLike(this: void, object: unknown): boolean;
    /**
     * Checks whether one of the given pattern matches given string.
     * @param target - Target to check in pattern for.
     * @param pattern - List of pattern to check for.
     *
     * @returns Value "true" if given object is matches by at leas one of the
     * given pattern and "false" otherwise.
     */
    static isAnyMatching(this: void, target: string, pattern: Array<string | RegExp>): boolean;
    /**
     * Checks whether given object is a native object but not null.
     * @param value - Value to check.
     *
     * @returns Value "true" if given object is a plain javaScript object and
     * "false" otherwise.
     */
    static isObject(this: void, value: unknown): value is Mapping<unknown>;
    /**
     * Checks whether given object is a plain native object.
     * @param value - Value to check.
     *
     * @returns Value "true" if given object is a plain javaScript object and
     * "false" otherwise.
     */
    static isPlainObject(this: void, value: unknown): value is PlainObject;
    /**
     * Checks whether given object is a set.
     * @param value - Value to check.
     *
     * @returns Value "true" if given object is a set and "false" otherwise.
     */
    static isSet(this: void, value: unknown): value is Set<unknown>;
    /**
     * Checks whether given object is a map.
     * @param value - Value to check.
     *
     * @returns Value "true" if given object is a map and "false" otherwise.
     */
    static isMap(this: void, value: unknown): value is Map<unknown, unknown>;
    /**
     * Checks whether given object is a proxy.
     * @param value - Value to check.
     *
     * @returns Value "true" if given object is a proxy and "false" otherwise.
     */
    static isProxy(this: void, value: unknown): value is ProxyType;
    /**
     * Checks whether given object is a function.
     * @param value - Value to check.
     *
     * @returns Value "true" if given object is a function and "false"
     * otherwise.
     */
    static isFunction(this: void, value: unknown): value is AnyFunction;
    /**
     * Shows the given object's representation in the browsers console if
     * possible or in a standalone alert-window as fallback.
     * @param object - Any object to print.
     * @param force - If set to "true" given input will be shown independently
     * from current logging configuration or interpreter's console
     * implementation.
     * @param avoidAnnotation - If set to "true" given input has no module or
     * log level specific annotations.
     * @param level - Description of log messages importance.
     * @param additionalArguments - Additional arguments are used for string
     * formatting.
     *
     * @returns Nothing.
     */
    log(object: unknown, force?: boolean, avoidAnnotation?: boolean, level?: keyof Console, ...additionalArguments: Array<unknown>): void;
    /**
     * Wrapper method for the native console method usually provided by
     * interpreter.
     * @param object - Any object to print.
     * @param additionalArguments - Additional arguments are used for string
     * formatting.
     *
     * @returns Nothing.
     */
    info(object: unknown, ...additionalArguments: Array<unknown>): void;
    /**
     * Wrapper method for the native console method usually provided by
     * interpreter.
     * @param object - Any object to print.
     * @param additionalArguments - Additional arguments are used for string
     * formatting.
     *
     * @returns Nothing.
     */
    debug(object: unknown, ...additionalArguments: Array<unknown>): void;
    /**
     * Wrapper method for the native console method usually provided by
     * interpreter.
     * @param object - Any object to print.
     * @param additionalArguments - Additional arguments are used for string
     * formatting.
     *
     * @returns Nothing.
     */
    error(object: unknown, ...additionalArguments: Array<unknown>): void;
    /**
     * Wrapper method for the native console method usually provided by
     * interpreter.
     * @param object - Any object to print.
     * @param additionalArguments - Additional arguments are used for string
     * formatting.
     *
     * @returns Nothing.
     */
    critical(object: unknown, ...additionalArguments: Array<unknown>): void;
    /**
     * Wrapper method for the native console method usually provided by
     * interpreter.
     * @param object - Any object to print.
     * @param additionalArguments - Additional arguments are used for string
     * formatting.
     *
     * @returns Nothing.
     */
    warn(object: unknown, ...additionalArguments: Array<unknown>): void;
    /**
     * Dumps a given object in a human readable format.
     * @param object - Any object to show.
     * @param level - Number of levels to dig into given object recursively.
     * @param currentLevel - Maximal number of recursive function calls to
     * represent given object.
     *
     * @returns Returns the serialized version of given object.
     */
    static show(this: void, object: unknown, level?: number, currentLevel?: number): string;
    /**
     * Deletes a cookie value by given name.
     * @param name - Name to identify requested value.
     *
     * @returns Nothing.
     */
    static deleteCookie(this: void, name: string): void;
    /**
     * Gets a cookie value by given name.
     * @param name - Name to identify requested value.
     *
     * @returns Requested value.
     */
    static getCookie(this: void, name: string): string | null;
    /**
     * Sets a cookie key-value-pair.
     * @param name - Name to identify given value.
     * @param value - Value to set.
     * @param givenOptions - Cookie set options.
     * @param givenOptions.domain - Domain to reference with given
     * key-value-pair.
     * @param givenOptions.httpOnly - Indicates if this cookie should be
     * accessible from client or not.

     * @param givenOptions.minimal - Set only minimum number of options.
     * @param givenOptions.numberOfDaysUntilExpiration - Number of days until
     * given key shouldn't be deleted.
     * @param givenOptions.path - Path to reference with given key-value-pair.
     * @param givenOptions.sameSite - Set same site policy to "Lax", "None" or
     * "Strict".
     * @param givenOptions.secure - Indicates if this cookie is only valid for
     * "https" connections.
     *
     * @returns A boolean indicating whether cookie could be set or not.
     */
    static setCookie(this: void, name: string, value: string, givenOptions?: Partial<CookieOptions>): boolean;
    /**
     * Normalizes class name order of current dom node.
     * @returns Current instance.
     */
    get normalizedClassNames(): this;
    /**
     * Normalizes style attributes order of current dom node.
     * @returns Returns current instance.
     */
    get normalizedStyles(): this;
    /**
     * Retrieves a mapping of computed style attributes to their corresponding
     * values.
     * @returns The computed style mapping.
     */
    get style(): Mapping<number | string>;
    /**
     * Get text content of current element without it children's text contents.
     * @returns The text string.
     */
    get text(): string;
    /**
     * Checks whether given html or text strings are equal.
     * @param first - First html, selector to dom node or text to compare.
     * @param second - Second html, selector to dom node  or text to compare.
     * @param forceHTMLString - Indicates whether given contents are
     * interpreted as html string (otherwise an automatic detection will be
     * triggered).
     *
     * @returns Returns true if both dom representations are equivalent.
     */
    static isEquivalentDOM(this: void, first: Node | string | $T<HTMLElement> | $T<Node>, second: Node | string | $T<HTMLElement> | $T<Node>, forceHTMLString?: boolean): boolean;
    /**
     * Determines where current dom node is relative to current view port
     * position.
     * @param givenDelta - Allows deltas for "top", "left", "bottom" and
     * "right" for determining positions.
     * @param givenDelta.bottom - Bottom delta.
     * @param givenDelta.left - Left delta.
     * @param givenDelta.right - Right delta.
     * @param givenDelta.top - Top delta.
     *
     * @returns Returns one of "above", "left", "below", "right" or "in".
     */
    getPositionRelativeToViewport(givenDelta?: {
        bottom?: number;
        left?: number;
        right?: number;
        top?: number;
    }): RelativePosition;
    /**
     * Generates a directive name corresponding selector string.
     * @param directiveName - The directive name.
     *
     * @returns Returns generated selector.
     */
    static generateDirectiveSelector(this: void, directiveName: string): string;
    /**
     * Removes a directive name corresponding class or attribute.
     * @param directiveName - The directive name.
     *
     * @returns Returns current dom node.
     */
    removeDirective(directiveName: string): null | $T<TElement>;
    /**
     * Hide or show all marked nodes which should be displayed depending on
     * java script availability.
     * @returns Nothing.
     */
    renderJavaScriptDependentVisibility(): void;
    /**
     * Determines a normalized camel case directive name representation.
     * @param directiveName - The directive name.
     *
     * @returns Returns the corresponding name.
     */
    static getNormalizedDirectiveName(this: void, directiveName: string): string;
    /**
     * Determines a directive attribute value.
     * @param directiveName - The directive name.
     *
     * @returns Returns the corresponding attribute value or "null" if no
     * attribute value exists.
     */
    getDirectiveValue(directiveName: string): null | string;
    /**
     * Removes a selector prefix from a given selector. This methods searches
     * in the options object for a given "domNodeSelectorPrefix".
     * @param domNodeSelector - The dom node selector to slice.
     * @returns Returns the sliced selector.
     */
    sliceDomNodeSelectorPrefix(domNodeSelector: string): string;
    /**
     * Determines the dom node name of a given dom node string.
     * @param domNodeSelector - A given to dom node selector to determine its
     * name.
     *
     * @returns Returns The dom node name.
     * @example
     * // returns 'div'
     * $.Tools.getDomNodeName('&lt;div&gt;')
     * @example
     * // returns 'div'
     * $.Tools.getDomNodeName('&lt;div&gt;&lt;/div&gt;')
     * @example
     * // returns 'br'
     * $.Tools.getDomNodeName('&lt;br/&gt;')
     */
    static getDomNodeName(this: void, domNodeSelector: string): null | string;
    /**
     * Converts an object of dom selectors to an array of $ wrapped dom nodes.
     * Note if selector description as one of "class" or "id" as suffix element
     * will be ignored.
     * @param domNodeSelectors - An object with dom node selectors.
     * @param wrapperDomNode - A dom node to be the parent or wrapper of all
     * retrieved dom nodes.
     *
     * @returns Returns All $ wrapped dom nodes corresponding to given
     * selectors.
     */
    grabDomNodes(domNodeSelectors: Mapping, wrapperDomNode?: Node | null | string | $T<Node>): $DomNodes;
    /**
     * Overwrites all inherited variables from parent scope with "undefined".
     * @param scope - A scope where inherited names will be removed.
     * @param prefixesToIgnore - Name prefixes to ignore during deleting names
     * in given scope.
     *
     * @returns The isolated scope.
     */
    static isolateScope<T extends Mapping<unknown>>(this: void, scope: T, prefixesToIgnore?: Array<string>): T;
    /**
     * Generates a unique name in given scope (useful for jsonp requests).
     * @param prefix - A prefix which will be prepended to unique name.
     * @param suffix - A suffix which will be prepended to unique name.
     * @param scope - A scope where the name should be unique.
     * @param initialUniqueName - An initial scope name to use if not exists.
     *
     * @returns The function name.
     */
    static determineUniqueScopeName(this: void, prefix?: string, suffix?: string, scope?: Mapping<unknown>, initialUniqueName?: string): string;
    /**
     * Determines all parameter names from given callable (function or class,
     * ...).
     * @param callable - Function or function code to inspect.
     *
     * @returns List of parameter names.
     */
    static getParameterNames(this: void, callable: AnyFunction | string): Array<string>;
    /**
     * Implements the identity function.
     * @param value - A value to return.
     *
     * @returns Returns the given value.
     */
    static identity<T>(this: void, value: T): T;
    /**
     * Inverted filter helper to inverse each given filter.
     * @param filter - A function that filters an array.
     *
     * @returns The inverted filter.
     */
    static invertArrayFilter<T>(this: void, filter: T): T;
    /**
     * Triggers given callback after given duration. Supports unlimited
     * duration length and returns a promise which will be resolved after given
     * duration has been passed.
     * @param parameters - Observes the first three existing parameters. If one
     * is a number it will be interpret as delay in milliseconds until given
     * callback will be triggered. If one is of type function it will be used
     * as callback and if one is of type boolean it will indicate if returning
     * promise should be rejected or resolved if given internally created
     * timeout should be canceled. Additional parameters will be forwarded to
     * given callback.
     *
     * @returns A promise resolving after given delay or being rejected if
     * value "true" is within one of the first three parameters. The promise
     * holds a boolean indicating whether timeout has been canceled or
     * resolved.
     */
    static timeout(this: void, ...parameters: Array<unknown>): TimeoutPromise;
    /**
     * Prevents event functions from triggering to often by defining a minimal
     * span between each function call. Additional arguments given to this
     * function will be forwarded to given event function call.
     * @param callback - The function to call debounced.
     * @param thresholdInMilliseconds - The minimum time span between each
     * function call.
     * @param additionalArguments - Additional arguments to forward to given
     * function.
     *
     * @returns Returns the wrapped method.
     */
    static debounce<T = unknown>(this: void, callback: UnknownFunction, thresholdInMilliseconds?: number, ...additionalArguments: Array<unknown>): ((..._parameters: Array<unknown>) => Promise<T>);
    /**
     * Searches for internal event handler methods and runs them by default. In
     * addition this method searches for a given event method by the options
     * object. Additional arguments are forwarded to respective event
     * functions.
     * @param eventName - An event name.
     * @param callOnlyOptionsMethod - Prevents from trying to call an internal
     * event handler.
     * @param scope - The scope from where the given event handler should be
     * called.
     * @param additionalArguments - Additional arguments to forward to
     * corresponding event handlers.
     *
     * @returns - Returns result of an options event handler (when called) and
     * "true" otherwise.
     */
    fireEvent(eventName: string, callOnlyOptionsMethod?: boolean, scope?: unknown, ...additionalArguments: Array<unknown>): unknown;
    /**
     * A wrapper method for "$.on()". It sets current plugin name as event
     * scope if no scope is given. Given arguments are modified and passed
     * through "$.on()".
     * @param parameters - Parameter to forward.
     *
     * @returns Returns $'s grabbed dom node.
     */
    on<TElement = HTMLElement>(...parameters: Array<unknown>): $T<TElement>;
    /**
     * A wrapper method fo "$.off()". It sets current plugin name as event
     * scope if no scope is given. Given arguments are modified and passed
     * through "$.off()".
     * @param parameters - Parameter to forward.
     *
     * @returns Returns $'s grabbed dom node.
     */
    off<TElement = HTMLElement>(...parameters: Array<unknown>): $T<TElement>;
    /**
     * Adds dynamic getter and setter to any given data structure such as maps.
     * @param object - Object to proxy.
     * @param getterWrapper - Function to wrap each property get.
     * @param setterWrapper - Function to wrap each property set.
     * @param methodNames - Method names to perform actions on the given
     * object.
     * @param deep - Indicates to perform a deep wrapping of specified types.
     * @param typesToExtend - Types which should be extended (Checks are
     * performed via "value instanceof type".).
     *
     * @returns Returns given object wrapped with a dynamic getter proxy.
     */
    static addDynamicGetterAndSetter<T = unknown>(this: void, object: T, getterWrapper?: GetterFunction | null, setterWrapper?: null | SetterFunction, methodNames?: Mapping, deep?: boolean, typesToExtend?: Array<unknown>): ProxyType<T> | T;
    /**
     * Converts given object into its serialized json representation by
     * replacing circular references with a given provided value.
     *
     * This method traverses given object recursively and tracks of seen and
     * already serialized structures to reuse generated strings or mark a
     * circular reference.
     * @param object - Object to serialize.
     * @param determineCircularReferenceValue - Callback to create a fallback
     * value depending on given redundant value.
     * @param numberOfSpaces - Number of spaces to use for string formatting.
     *
     * @returns The formatted json string.
     */
    static convertCircularObjectToJSON(this: void, object: unknown, determineCircularReferenceValue?: ((_serializedValue: null | unknown, _key: null | string, _value: unknown, _seenObjects: Map<unknown, null | unknown>) => unknown), numberOfSpaces?: number): ReturnType<typeof JSON.stringify> | undefined;
    /**
     * Converts given map and all nested found maps objects to corresponding
     * object.
     * @param object - Map to convert to.
     * @param deep - Indicates whether to perform a recursive conversion.
     *
     * @returns Given map as object.
     */
    static convertMapToPlainObject(this: void, object: unknown, deep?: boolean): unknown;
    /**
     * Converts given plain object and all nested found objects to
     * corresponding map.
     * @param object - Object to convert to.
     * @param deep - Indicates whether to perform a recursive conversion.
     *
     * @returns Given object as map.
     */
    static convertPlainObjectToMap(this: void, object: unknown, deep?: boolean): unknown;
    /**
     * Replaces given pattern in each value in given object recursively with
     * given string replacement.
     * @param object - Object to convert substrings in.
     * @param pattern - Regular expression to replace.
     * @param replacement - String to use as replacement for found patterns.
     *
     * @returns Converted object with replaced patterns.
     */
    static convertSubstringInPlainObject<Type extends Mapping<unknown> = PlainObject>(this: void, object: Type, pattern: RegExp | string, replacement: string): Type;
    /**
     * Copies given object (of any type) into optionally given destination.
     * @param source - Object to copy.
     * @param recursionLimit - Specifies how deep we should traverse into given
     * object recursively.
     * @param recursionEndValue - Indicates which value to use for recursion
     * ends. Usually a reference to corresponding source value will be used.
     * @param destination - Target to copy source to.
     * @param cyclic - Indicates whether known sub structures should be copied
     * or referenced (if "true" endless loops can occur if source has cyclic
     * structures).
     * @param knownReferences - Used to avoid traversing loops and not to copy
     * references e.g. to objects not to copy (e.g. symbol polyfills).
     * @param recursionLevel - Internally used to track current recursion
     * level in given source data structure.
     *
     * @returns Value "true" if both objects are equal and "false" otherwise.
     */
    static copy<Type = unknown>(this: void, source: Type, recursionLimit?: number, recursionEndValue?: unknown, destination?: null | Type, cyclic?: boolean, knownReferences?: Array<unknown>, recursionLevel?: number): Type;
    /**
     * Determine the internal JavaScript [[Class]] of an object.
     * @param value - Value to analyze.
     *
     * @returns Name of determined type.
     */
    static determineType(this: void, value?: unknown): string;
    /**
     * Returns true if given items are equal for given property list. If
     * property list isn't set all properties will be checked. All keys which
     * starts with one of the exception prefixes will be omitted.
     * @param firstValue - First object to compare.
     * @param secondValue - Second object to compare.
     *
     * @param givenOptions - Options to define how to compare.
     * @param givenOptions.properties - Property names to check. Check all if
     * "null" is selected (default).
     * @param givenOptions.deep - Recursion depth negative values means
     * infinitely deep (default).
     * @param givenOptions.exceptionPrefixes - Property prefixes which
     * indicates properties to ignore.
     * @param givenOptions.ignoreFunctions - Indicates whether functions have
     * to be identical to interpret is as equal. If set to "true" two functions
     * will be assumed to be equal (default).
     * @param givenOptions.compareBlobs - Indicates whether binary data should
     * be converted to a base64 string to compare their content. Makes this
     * function asynchronous in browsers and potentially takes a lot of
     * resources.
     *
     * @returns Value "true" if both objects are equal and "false" otherwise.
     * If "compareBlobs" is activated and we're running in a browser like
     * environment and binary data is given, then a promise wrapping the
     * determined boolean values is returned.
     */
    static equals(this: void, firstValue: unknown, secondValue: unknown, givenOptions?: Partial<CompareOptions>): boolean | Promise<boolean | string> | string;
    /**
     * Searches for nested mappings with given indicator key and resolves
     * marked values. Additionally all objects are wrapped with a proxy to
     * dynamically resolve nested properties.
     * @param object - Given mapping to resolve.
     * @param scope - Scope to to use evaluate again.
     * @param selfReferenceName - Name to use for reference to given object.
     * @param expressionIndicatorKey - Indicator property name to mark a value
     * to evaluate.
     * @param executionIndicatorKey - Indicator property name to mark a value
     * to evaluate.
     *
     * @returns Evaluated given mapping.
     */
    static evaluateDynamicData<Type = unknown>(this: void, object: null | RecursiveEvaluateable<Type>, scope?: Mapping<unknown>, selfReferenceName?: string, expressionIndicatorKey?: string, executionIndicatorKey?: string): Type;
    /**
     * Removes properties in objects where a dynamic indicator lives.
     * @param data - Object to traverse recursively.
     * @param expressionIndicators - Property key to remove.
     *
     * @returns Given object with removed properties.
     */
    static removeKeysInEvaluation<T extends Mapping<unknown> = Mapping<unknown>>(this: void, data: T, expressionIndicators?: Array<string>): T;
    /**
     * Extends given target object with given sources object. As target and
     * sources many expandable types are allowed but target and sources have to
     * to come from the same type.
     * @param targetOrDeepIndicator - Maybe the target or deep indicator.
     * @param targetOrSource - Target or source object; depending on first
     * argument.
     * @param additionalSources - Source objects to extend into target.
     *
     * @returns Returns given target extended with all given sources.
     */
    static extend<T = Mapping<unknown>>(this: void, targetOrDeepIndicator: (boolean | typeof IgnoreNullAndUndefinedSymbol | RecursivePartial<T>), targetOrSource?: RecursivePartial<T>, ...additionalSources: Array<RecursivePartial<T>>): T;
    /**
     * Retrieves substructure in given object referenced by given selector
     * path.
     * @param target - Object to search in.
     * @param selector - Selector path.
     * @param skipMissingLevel - Indicates to skip missing level in given path.
     * @param delimiter - Delimiter to delimit given selector components.
     *
     * @returns Determined sub structure of given data or "undefined".
     */
    static getSubstructure<T = unknown, E = unknown>(this: void, target: T, selector: Selector<T, E>, skipMissingLevel?: boolean, delimiter?: string): E;
    /**
     * Generates a proxy handler which forwards all operations to given object
     * as there wouldn't be a proxy.
     * @param target - Object to proxy.
     * @param methodNames - Mapping of operand name to object specific method
     * name.
     *
     * @returns Determined proxy handler.
     */
    static getProxyHandler<T = unknown>(this: void, target: T, methodNames?: Mapping): ProxyHandler<T>;
    /**
     * Slices all properties from given object which does not match provided
     * object mask. Items can be explicitly white listed via "include" mask
     * configuration or black listed via "exclude" mask configuration.
     * @param object - Object to slice.
     * @param mask - Mask configuration.
     *
     * @returns Given but sliced object. If (nested) object will be modified a
     * flat copy of that object will be returned.
     */
    static mask<Type extends Mapping<unknown> = Mapping<unknown>>(this: void, object: Type, mask: ObjectMaskConfiguration): RecursivePartial<Type>;
    /**
     * Modifies given target corresponding to given source and removes source
     * modification infos.
     * @param target - Object to modify.
     * @param source - Source object to load modifications from.
     * @param removeIndicatorKey - Indicator property name or value to mark a
     * value to remove from object or list.
     * @param prependIndicatorKey - Indicator property name to mark a value to
     * prepend to target list.
     * @param appendIndicatorKey - Indicator property name to mark a value to
     * append to target list.
     * @param positionPrefix - Indicates a prefix to use a value on given
     * position to add or remove.
     * @param positionSuffix - Indicates a suffix to use a value on given
     * position to add or remove.
     * @param parentSource - Source context to remove modification info from
     * (usually only needed internally).
     * @param parentKey - Source key in given source context to remove
     * modification info from (usually only needed internally).
     *
     * @returns Given target modified with given source.
     */
    static modifyObject<T = unknown>(this: void, target: T, source: unknown, removeIndicatorKey?: string, prependIndicatorKey?: string, appendIndicatorKey?: string, positionPrefix?: string, positionSuffix?: string, parentSource?: unknown, parentKey?: unknown): T | null;
    /**
     * Interprets a date object from given artefact.
     * @param value - To interpret.
     * @param interpretAsUTC - Identifies if given date should be interpret as
     * utc.
     *
     * @returns Interpreted date object or "null" if given value couldn't be
     * interpret.
     */
    static normalizeDateTime(this: void, value?: string | null | number | Date, interpretAsUTC?: boolean): Date | null;
    /**
     * Removes given key from given object recursively.
     * @param object - Object to process.
     * @param keys - List of keys to remove.
     *
     * @returns Processed given object.
     */
    static removeKeyPrefixes<T>(this: void, object: T, keys?: Array<string> | string): T;
    /**
     * Represents given object as formatted string.
     * @param object - Object to represent.
     * @param indention - String (usually whitespaces) to use as indention.
     * @param initialIndention - String (usually whitespaces) to use as
     * additional indention for the first object traversing level.
     * @param maximumNumberOfLevelsReachedIdentifier - Replacement for objects
     * which are out of specified bounds to traverse.
     * @param numberOfLevels - Specifies number of levels to traverse given
     * data structure.
     *
     * @returns Representation string.
     */
    static represent(this: void, object: unknown, indention?: string, initialIndention?: string, maximumNumberOfLevelsReachedIdentifier?: number | string, numberOfLevels?: number): string;
    /**
     * Sort given objects keys.
     * @param object - Object which keys should be sorted.
     *
     * @returns Sorted list of given keys.
     */
    static sort(this: void, object: unknown): Array<unknown>;
    /**
     * Removes a proxy from given data structure recursively.
     * @param object - Object to proxy.
     * @param seenObjects - Tracks all already processed objects to avoid
     * endless loops (usually only needed for internal purpose).
     *
     * @returns Returns given object unwrapped from a dynamic proxy.
     */
    static unwrapProxy<T = unknown>(this: void, object: ProxyType<T> | T, seenObjects?: Set<unknown>): T;
    /**
     * Summarizes given property of given item list.
     * @param data - Array of objects with given property name.
     * @param propertyName - Property name to summarize.
     * @param defaultValue - Value to return if property values doesn't match.
     *
     * @returns Aggregated value.
     */
    static arrayAggregatePropertyIfEqual<T = unknown>(this: void, data: Array<Mapping<unknown>>, propertyName: string, defaultValue?: T): T;
    /**
     * Deletes every item witch has only empty attributes for given property
     * names. If given property names are empty each attribute will be
     * considered. The empty string, "null" and "undefined" will be interpreted
     * as empty.
     * @param data - Data to filter.
     * @param propertyNames - Properties to consider.
     *
     * @returns Given data without empty items.
     */
    static arrayDeleteEmptyItems<T extends Mapping<unknown> = Mapping<unknown>>(this: void, data: Array<T>, propertyNames?: Array<string | symbol>): Array<T>;
    /**
     * Extracts all properties from all items wich occur in given property
     * names.
     * @param data - Data where each item should be sliced.
     * @param propertyNames - Property names to extract.
     *
     * @returns Data with sliced items.
     */
    static arrayExtract<T = Mapping<unknown>>(this: void, data: unknown, propertyNames: Array<string>): Array<T>;
    /**
     * Extracts all values which matches given regular expression.
     * @param data - Data to filter.
     * @param regularExpression - Pattern to match for.
     *
     * @returns Filtered data.
     */
    static arrayExtractIfMatches(this: void, data: unknown, regularExpression: string | RegExp): Array<string>;
    /**
     * Filters given data if given property is set or not.
     * @param data - Data to filter.
     * @param propertyName - Property name to check for existence.
     *
     * @returns Given data without the items which doesn't have specified
     * property.
     */
    static arrayExtractIfPropertyExists<T extends Mapping<unknown> = Mapping<unknown>>(this: void, data: unknown, propertyName: string): Array<T>;
    /**
     * Extract given data where specified property value matches given
     * patterns.
     * @param data - Data to filter.
     * @param propertyPattern - Mapping of property names to pattern.
     *
     * @returns Filtered data.
     */
    static arrayExtractIfPropertyMatches<T = unknown>(this: void, data: unknown, propertyPattern: Mapping<RegExp | string>): Array<T>;
    /**
     * Determines all objects which exists in "first" and in "second".
     * Object key which will be compared are given by "keys". If an empty array
     * is given each key will be compared. If an object is given corresponding
     * initial data key will be mapped to referenced new data key.
     * @param first - Referenced data to check for.
     * @param second - Data to check for existence.
     * @param keys - Keys to define equality.
     * @param strict - The strict parameter indicates whether "null" and
     * "undefined" should be interpreted as equal (takes only effect if given
     * keys aren't empty).
     *
     * @returns Data which does exit in given initial data.
     */
    static arrayIntersect<T = unknown>(this: void, first: unknown, second: unknown, keys?: Array<string> | Mapping<number | string>, strict?: boolean): Array<T>;
    /**
     * Converts given object into an array.
     * @param object - Target to convert.
     *
     * @returns Generated array.
     */
    static arrayMake<T = unknown>(this: void, object: unknown): Array<T>;
    /**
     * Creates a list of items within given range.
     * @param range - Array of lower and upper bounds. If only one value is
     * given lower bound will be assumed to be zero. Both integers have to be
     * positive and will be contained in the resulting array. If more than two
     * numbers are provided given range will be returned.
     * @param step - Space between two consecutive values.
     * @param ignoreLastStep - Removes last step.
     *
     * @returns Produced array of integers.
     */
    static arrayMakeRange(this: void, range: number | [number] | [number, number] | Array<number>, step?: number, ignoreLastStep?: boolean): Array<number>;
    /**
     * Merge the contents of two arrays together into the first array.
     * @param target - Target array.
     * @param source - Source array.
     *
     * @returns Target array with merged given source one.
     */
    static arrayMerge<T = unknown>(this: void, target: Array<T>, source: Array<T>): Array<T>;
    /**
     * Generates a list if pagination symbols to render a pagination from.
     * @param options - Configure bounds and current page of pagination to
     * determine.
     * @param options.boundaryCount - Indicates where to start pagination
     * within given total range.
     * @param options.disabled - Indicates whether to disable all items.
     * @param options.hideNextButton - Indicates whether to show a jump to next
     * item.
     * @param options.hidePrevButton - Indicates whether to show a jump to
     * previous item.
     * @param options.page - Indicates current visible page.
     * @param options.pageSize - Number of items per page.
     * @param options.showFirstButton - Indicates whether to show a jump to
     * first item.
     * @param options.showLastButton - Indicates whether to show a jump to last
     * item.
     * @param options.siblingCount - Number of sibling page symbols next to
     * current page symbol.
     * @param options.total - Number of all items to paginate.
     *
     * @returns A list of pagination symbols.
     */
    static arrayPaginate(this: void, options?: Partial<PaginateOptions>): Array<Page>;
    /**
     * Generates all permutations of given iterable.
     * @param data - Array like object.
     *
     * @returns Array of permuted arrays.
     */
    static arrayPermutate<T = unknown>(this: void, data: Array<T>): Array<Array<T>>;
    /**
     * Generates all lengths permutations of given iterable.
     * @param data - Array like object.
     * @param minimalSubsetLength - Defines how long the minimal subset length
     * should be.
     *
     * @returns Array of permuted arrays.
     */
    static arrayPermutateLength<T = unknown>(this: void, data: Array<T>, minimalSubsetLength?: number): Array<Array<T>>;
    /**
     * Sums up given property of given item list.
     * @param data - The objects with specified property to sum up.
     * @param propertyName - Property name to sum up its value.
     *
     * @returns The aggregated value.
     */
    static arraySumUpProperty(this: void, data: unknown, propertyName: string): number;
    /**
     * Adds an item to another item as array connection (many to one).
     * @param item - Item where the item should be appended to.
     * @param target - Target to add to given item.
     * @param name - Name of the target connection.
     * @param checkIfExists - Indicates if duplicates are allowed in resulting
     * list (will result in linear runtime instead of constant one).
     *
     * @returns Item with the appended target.
     */
    static arrayAppendAdd<T = unknown>(this: void, item: Mapping<T>, target: unknown, name: string, checkIfExists?: boolean): Mapping<T>;
    /**
     * Removes given target on given list.
     * @param list - Array to splice.
     * @param target - Target to remove from given list.
     * @param strict - Indicates whether to fire an exception if given target
     * doesn't exists given list.
     *
     * @returns Item with the appended target.
     */
    static arrayRemove<T = unknown>(this: void, list: Array<T>, target: T, strict?: boolean): Array<T>;
    /**
     * Sorts given object of dependencies in a topological order.
     * @param items - Items to sort.
     *
     * @returns Sorted array of given items respecting their dependencies.
     */
    static arraySortTopological(this: void, items: Mapping<Array<string> | string>): Array<string>;
    /**
     * Makes all values in given iterable unique by removing duplicates (The
     * first occurrences will be left).
     * @param data - Array like object.
     *
     * @returns Sliced version of given object.
     */
    static arrayUnique<T = unknown>(this: void, data: Array<T>): Array<T>;
    /**
     * Translates given string into the regular expression validated
     * representation.
     * @param value - String to convert.
     * @param excludeSymbols - Symbols not to escape.
     *
     * @returns Converted string.
     */
    static stringEscapeRegularExpressions(this: void, value: string, excludeSymbols?: Array<string>): string;
    /**
     * Translates given name into a valid javaScript one.
     * @param name - Name to convert.
     * @param allowedSymbols - String of symbols which should be allowed within
     * a variable name (not the first character).
     *
     * @returns Converted name is returned.
     */
    static stringConvertToValidVariableName(this: void, name: string, allowedSymbols?: string): string;
    /**
     * This method is intended for encoding *key* or *value* parts of query
     * component. We need a custom method because "encodeURIComponent()" is too
     * aggressive and encodes stuff that doesn't have to be encoded per
     * "http://tools.ietf.org/html/rfc3986:".
     * @param url - URL to encode.
     * @param encodeSpaces - Indicates whether given url should encode
     * whitespaces as "+" or "%20".
     *
     * @returns Encoded given url.
     */
    static stringEncodeURIComponent(this: void, url: string, encodeSpaces?: boolean): string;
    /**
     * Appends a path selector to the given path if there isn't one yet.
     * @param path - The path for appending a selector.
     * @param pathSeparator - The selector for appending to path.
     *
     * @returns The appended path.
     */
    static stringAddSeparatorToPath(this: void, path: string, pathSeparator?: string): string;
    /**
     * Checks if given path has given path prefix.
     * @param prefix - Path prefix to search for.
     * @param path - Path to search in.
     * @param separator - Delimiter to use in path (default is the posix
     * conform slash).
     *
     * @returns Value "true" if given prefix occur and "false" otherwise.
     */
    static stringHasPathPrefix(this: void, prefix?: unknown, path?: string, separator?: string): boolean;
    /**
     * Extracts domain name from given url. If no explicit domain name given
     * current domain name will be assumed. If no parameter given current
     * domain name will be determined.
     * @param url - The url to extract domain from.
     * @param fallback - The fallback host name if no one exits in given url
     * (default is current hostname).
     *
     * @returns Extracted domain.
     */
    static stringGetDomainName(this: void, url?: string, fallback?: string): string;
    /**
     * Extracts port number from given url. If no explicit port number given
     * and no fallback is defined current port number will be assumed for local
     * links. For external links 80 will be assumed for http protocols and 443
     * for https protocols.
     * @param url - The url to extract port from.
     * @param fallback - Fallback port number if no explicit one was found.
     * Default is derived from current protocol name.
     *
     * @returns Extracted port number.
     */
    static stringGetPortNumber(this: void, url?: string, fallback?: null | number): null | number;
    /**
     * Extracts protocol name from given url. If no explicit url is given,
     * current protocol will be assumed. If no parameter given current protocol
     * number will be determined.
     * @param url - The url to extract protocol from.
     * @param fallback - Fallback port to use if no protocol exists in given
     * url (default is current protocol).
     *
     * @returns Extracted protocol.
     */
    static stringGetProtocolName(this: void, url?: string, fallback?: string): string;
    /**
     * Read a page's GET URL variables and return them as an associative array
     * and preserves ordering.
     * @param keyToGet - If provided the corresponding value for given key is
     * returned or full object otherwise.
     * @param allowDuplicates - Indicates whether to return arrays of values or
     * single values. If set to "false" (default) last values will overwrite
     * preceding values.
     * @param givenInput - An alternative input to the url search parameter. If
     * "#" is given the complete current hash tag will be interpreted as url
     * and search parameter will be extracted from there. If "&" is given
     * classical search parameter and hash parameter will be taken in account.
     * If a search string is given this will be analyzed. The default is to
     * take given search part into account.
     * @param subDelimiter - Defines which sequence indicates the start of
     * parameter in a hash part of the url.
     * @param hashedPathIndicator - If defined and given hash starts with this
     * indicator given hash will be interpreted as path containing search and
     * hash parts.
     * @param givenSearch - Search part to take into account defaults to
     * current url search part.
     * @param givenHash - Hash part to take into account defaults to current
     * url hash part.
     *
     * @returns Returns the current get array or requested value. If requested
     * key doesn't exist "undefined" is returned.
     */
    static stringGetURLParameter(this: void, keyToGet?: null | string, allowDuplicates?: boolean, givenInput?: null | string, subDelimiter?: string, hashedPathIndicator?: string, givenSearch?: null | string, givenHash?: string): Array<string> | null | QueryParameters | string;
    /**
     * Checks if given url points to another "service" than second given url.
     * If no second given url provided current url will be assumed.
     * @param url - URL to check against second url.
     * @param referenceURL - URL to check against first url.
     *
     * @returns Returns "true" if given first url has same domain as given
     * second (or current).
     */
    static stringServiceURLEquals(this: void, url: string, referenceURL?: string): boolean;
    /**
     * Normalized given website url.
     * @param url - Uniform resource locator to normalize.
     *
     * @returns Normalized result.
     */
    static stringNormalizeURL(this: void, url: string): string;
    /**
     * Represents given website url.
     * @param url - Uniform resource locator to represent.
     *
     * @returns Represented result.
     */
    static stringRepresentURL(this: void, url: unknown): string;
    /**
     * Converts a camel cased string to its delimited string version.
     * @param value - The string to format.
     * @param delimiter - Delimiter string
     * @param abbreviations - Collection of shortcut words to represent upper
     * cased.
     *
     * @returns The formatted string.
     */
    static stringCamelCaseToDelimited(this: void, value: string, delimiter?: string, abbreviations?: Array<string> | null): string;
    /**
     * Converts a string to its capitalize representation.
     * @param string - The string to format.
     *
     * @returns The formatted string.
     */
    static stringCapitalize(this: void, string: string): string;
    /**
     * Compresses given style attribute value.
     * @param styleValue - Style value to compress.
     *
     * @returns The compressed value.
     */
    static stringCompressStyleValue(this: void, styleValue: string): string;
    /**
     * Decodes all html symbols in text nodes in given html string.
     * @param htmlString - HTML string to decode.
     *
     * @returns Decoded html string.
     */
    static stringDecodeHTMLEntities(this: void, htmlString: string): null | string;
    /**
     * Converts a delimited string to its camel case representation.
     * @param value - The string to format.
     * @param delimiter - Delimiter string to use.
     * @param abbreviations - Collection of shortcut words to represent upper
     * cased.
     * @param preserveWrongFormattedAbbreviations - If set to "True" wrong
     * formatted camel case abbreviations will be ignored.
     * @param removeMultipleDelimiter - Indicates whether a series of delimiter
     * should be consolidated.
     *
     * @returns The formatted string.
     */
    static stringDelimitedToCamelCase(this: void, value: string, delimiter?: string, abbreviations?: Array<string> | null, preserveWrongFormattedAbbreviations?: boolean, removeMultipleDelimiter?: boolean): string;
    /**
     * Compiles a given string as expression with given scope names.
     * @param expression - The string to interpret.
     * @param scope - Scope to extract names from.
     * @param execute - Indicates whether to execute or evaluate.
     *
     * @returns Object of prepared scope name mappings and compiled function or
     * error string message if given expression couldn't be compiled.
     */
    static stringCompile<T = string>(this: void, expression: string, scope?: Array<string> | Mapping<unknown> | string, execute?: boolean): CompilationResult<T>;
    /**
     * Evaluates a given string as expression against given scope.
     * @param expression - The string to interpret.
     * @param scope - Scope to render against.
     * @param execute - Indicates whether to execute or evaluate.
     * @param binding - Object to apply as "this" in evaluation scope.
     *
     * @returns Object with error message during parsing / running or result.
     */
    static stringEvaluate<T = string>(this: void, expression: string, scope?: Mapping<unknown>, execute?: boolean, binding?: unknown): EvaluationResult<T>;
    /**
     * Finds the string match of given query in given target text by applying
     * given normalisation function to target and query.
     * @param target - Target to search in.
     * @param query - Search string to search for.
     * @param normalizer - Function to use as normalisation for queries and
     * search targets.
     * @param skipTagDelimitedParts - Indicates whether to for example ignore
     * html tags via "['<', '>']" (the default).
     *
     * @returns Start and end index of matching range.
     */
    static stringFindNormalizedMatchRange(this: void, target: unknown, query: unknown, normalizer?: (value: unknown) => string, skipTagDelimitedParts?: null | [string, string]): Array<number> | null;
    /**
     * Fixes known encoding problems in given data.
     * @param data - To process.
     *
     * @returns Processed data.
     */
    static stringFixKnownEncodingErrors(this: void, data: string): string;
    /**
     * Performs a string formation. Replaces every placeholder "{i}" with the
     * i'th argument.
     * @param string - The string to format.
     * @param additionalArguments - Additional arguments are interpreted as
     * replacements for string formatting.
     *
     * @returns The formatted string.
     */
    static stringFormat(this: void, string: string, ...additionalArguments: Array<unknown>): string;
    /**
     * Calculates the edit (levenstein) distance between two given strings.
     * @param first - First string to compare.
     * @param second - Second string to compare.
     *
     * @returns The distance as number.
     */
    static stringGetEditDistance(this: void, first: string, second: string): number;
    /**
     * Validates the current string for using in a regular expression pattern.
     * Special regular expression chars will be escaped.
     * @param value - The string to format.
     *
     * @returns The formatted string.
     */
    static stringGetRegularExpressionValidated(this: void, value: string): string;
    /**
     * Interprets given content string as date time.
     * @param value - Date time string to interpret.
     * @param interpretAsUTC - Identifies if given date should be interpret as
     * utc.
     *
     * @returns Interpret date time object.
     */
    static stringInterpretDateTime(this: void, value: string, interpretAsUTC?: boolean): Date | null;
    /**
     * Converts a string to its lower case representation.
     * @param string - The string to format.
     *
     * @returns The formatted string.
     */
    static stringLowerCase(this: void, string: string): string;
    /**
     * Wraps given mark strings in given target with given marker.
     * @param target - String to search for marker.
     * @param givenWords - String or array of strings to search in target for.
     * @param options - Defines highlighting behavior.
     * @param options.marker - HTML template string to mark.
     * @param options.normalizer - Pure normalisation function to use before
     * searching for matches.
     * @param options.skipTagDelimitedParts - Indicates whether to for example
     * ignore html tags via "['<', '>']" (the default).
     *
     * @returns Processed result.
     */
    static stringMark(this: void, target: unknown, givenWords?: Array<string> | string, options?: Partial<StringMarkOptions>): unknown;
    /**
     * Implements the md5 hash algorithm.
     * @param value - Value to calculate md5 hash for.
     * @param onlyAscii - Set to true if given input has ascii characters only
     * to get more performance.
     *
     * @returns Calculated md5 hash value.
     */
    static stringMD5(this: void, value: string, onlyAscii?: boolean): string;
    /**
     * Normalizes given phone number for automatic dialing or comparison.
     * @param value - Number to normalize.
     * @param dialable - Indicates whether the result should be dialed or
     * represented as lossless data.
     *
     * @returns Normalized number.
     */
    static stringNormalizePhoneNumber(this: void, value: unknown, dialable?: boolean): string;
    /**
     * Normalizes given zip code for automatic address processing.
     * @param value - Number to normalize.
     *
     * @returns Normalized number.
     */
    static stringNormalizeZipCode(this: void, value: unknown): string;
    /**
     * Converts given serialized, base64 encoded or file path given object into
     * a native javaScript one if possible.
     * @param serializedObject - Object as string.
     * @param scope - An optional scope which will be used to evaluate given
     * object in.
     * @param name - The name under given scope will be available.
     *
     * @returns The parsed object if possible and null otherwise.
     */
    static stringParseEncodedObject<T = PlainObject>(this: void, serializedObject: string, scope?: Mapping<unknown>, name?: string): null | T;
    /**
     * Represents given phone number. NOTE: Currently only support german phone
     * numbers.
     * @param value - Number to format.
     *
     * @returns Formatted number.
     */
    static stringRepresentPhoneNumber(this: void, value: unknown): string;
    /**
     * Slices all none numbers but preserves last separator.
     * @param value - String to process.
     *
     * @returns - Sliced given value.
     */
    static stringSliceAllExceptNumberAndLastSeperator(this: void, value: string): string;
    /**
     * Slice weekday from given date representation.
     * @param value - String to process.
     *
     * @returns Sliced given string.
     */
    static stringSliceWeekday(this: void, value: string): string;
    /**
     * Converts a dom selector to a prefixed dom selector string.
     * @param selector - A dom node selector.
     *
     * @returns Returns given selector prefixed.
     */
    stringNormalizeDomNodeSelector: (selector: string) => string;
    /**
     * Determines corresponding utc timestamp for given date object.
     * @param value - Date to convert.
     * @param inMilliseconds - Indicates whether given number should be in
     * seconds (default) or milliseconds.
     *
     * @returns Determined numerous value.
     */
    static numberGetUTCTimestamp(this: void, value?: Date | null | number | string, inMilliseconds?: boolean): number;
    /**
     * Checks if given object is java scripts native "Number.NaN" object.
     * @param value - Value to check.
     *
     * @returns Returns whether given value is not a number or not.
     */
    static numberIsNotANumber(this: void, value: unknown): boolean;
    /**
     * Rounds a given number accurate to given number of digits.
     * @param number - The number to round.
     * @param digits - The number of digits after comma.
     *
     * @returns Returns the rounded number.
     */
    static numberRound(this: void, number: number, digits?: number): number;
    /**
     * Rounds a given number up accurate to given number of digits.
     * @param number - The number to round.
     * @param digits - The number of digits after comma.
     *
     * @returns Returns the rounded number.
     */
    static numberCeil(this: void, number: number, digits?: number): number;
    /**
     * Rounds a given number down accurate to given number of digits.
     * @param number - The number to round.
     * @param digits - The number of digits after comma.
     *
     * @returns Returns the rounded number.
     */
    static numberFloor(this: void, number: number, digits?: number): number;
    /**
     * Checks if given url response with given status code.
     * @param url - Url to check reachability.
     *
     * @param givenOptions - Options to configure.
     * @param givenOptions.wait - Boolean indicating if we should retry until a
     * status code will be given.
     * @param givenOptions.statusCodes - Status codes to check for.
     * @param givenOptions.timeoutInSeconds - Delay after assuming given
     * resource isn't available if no response is coming.
     * @param givenOptions.pollIntervallInSeconds - Seconds between two tries
     * to reach given url.
     * @param givenOptions.options - Fetch options to use.
     * @param givenOptions.expectedIntermediateStatusCodes - A list of expected
     * but unwanted response codes. If detecting them waiting will continue
     * until an expected (positiv) code occurs or timeout is reached.
     *
     * @returns A promise which will be resolved if a request to given url has
     * finished and resulting status code matches given expected status code.
     * Otherwise returned promise will be rejected.
     */
    static checkReachability(this: void, url: string, givenOptions?: RecursivePartial<CheckReachabilityOptions>): ReturnType<typeof fetch>;
    /**
     * Checks if given url isn't reachable.
     * @param url - Url to check reachability.
     *
     * @param givenOptions - Options to configure.
     * @param givenOptions.wait - Boolean indicating if we should retry until a
     * status code will be given.
     * @param givenOptions.timeoutInSeconds - Delay after assuming given
     * resource will stay available.
     * @param givenOptions.pollIntervallInSeconds - Seconds between two tries
     * to reach given url.
     * @param givenOptions.statusCodes - Status codes to check for.
     * @param givenOptions.options - Fetch options to use.
     *
     * @returns A promise which will be resolved if a request to given url
     * couldn't finished. Otherwise returned promise will be rejected. If
     * "wait" is set to "true" we will resolve to another promise still
     * resolving when final timeout is reached or the endpoint is unreachable
     * (after some tries).
     */
    static checkUnreachability(this: void, url: string, givenOptions?: RecursivePartial<CheckReachabilityOptions>): Promise<Error | null | Promise<Error | null>>;
    /**
     * Send given data to a given iframe.
     * @param target - Name of the target iframe or the target iframe itself.
     * @param url - URL to send to data to.
     * @param data - Data holding object to send data to.
     * @param requestType - The forms action attribute value. If nothing is
     * provided "post" will be used as default.
     * @param removeAfterLoad - Indicates if created iframe should be removed
     * right after load event. Only works if an iframe object is given instead
     * of a simple target name.
     *
     * @returns Returns the given target as extended dom node.
     */
    static sendToIFrame(this: void, target: $T<HTMLIFrameElement> | HTMLIFrameElement | string, url: string, data: Mapping<unknown>, requestType?: string, removeAfterLoad?: boolean): $T<HTMLIFrameElement>;
    /**
     * Send given data to a temporary created iframe.
     * @param url - URL to send to data to.
     * @param data - Data holding object to send data to.
     * @param requestType - The forms action attribute value. If nothing is
     * provided "post" will be used as default.
     * @param removeAfterLoad - Indicates if created iframe should be removed
     * right after load event.
     *
     * @returns Returns the dynamically created iframe.
     */
    sendToExternalURL: (url: string, data: Mapping<unknown>, requestType?: string, removeAfterLoad?: boolean) => $T<HTMLIFrameElement>;
    /**
     * Copies given source directory via path to given target directory
     * location with same target name as source file has or copy to given
     * complete target directory path.
     * @param sourcePath - Path to directory to copy.
     * @param targetPath - Target directory or complete directory location to
     * copy in.
     * @param callback - Function to invoke for each traversed file.
     * @param readOptions - Options to use for reading source file.
     * @param writeOptions - Options to use for writing to target file.
     *
     * @returns Promise holding the determined target directory path.
     */
    static copyDirectoryRecursive(this: void, sourcePath: string, targetPath: string, callback?: AnyFunction, readOptions?: PlainObject, writeOptions?: PlainObject): Promise<string>;
    /**
     * Copies given source directory via path to given target directory
     * location with same target name as source file has or copy to given
     * complete target directory path.
     * @param sourcePath - Path to directory to copy.
     * @param targetPath - Target directory or complete directory location to
     * copy in.
     * @param callback - Function to invoke for each traversed file.
     * @param readOptions - Options to use for reading source file.
     * @param writeOptions - Options to use for writing to target file.
     *
     * @returns Determined target directory path.
     */
    static copyDirectoryRecursiveSync(this: void, sourcePath: string, targetPath: string, callback?: AnyFunction, readOptions?: PlainObject, writeOptions?: PlainObject): string;
    /**
     * Copies given source file via path to given target directory location
     * with same target name as source file has or copy to given complete
     * target file path.
     * @param sourcePath - Path to file to copy.
     * @param targetPath - Target directory or complete file location to copy
     * to.
     * @param readOptions - Options to use for reading source file.
     * @param writeOptions - Options to use for writing to target file.
     *
     * @returns Determined target file path.
     */
    static copyFile(this: void, sourcePath: string, targetPath: string, readOptions?: PlainObject, writeOptions?: PlainObject): Promise<string>;
    /**
     * Copies given source file via path to given target directory location
     * with same target name as source file has or copy to given complete
     * target file path.
     * @param sourcePath - Path to file to copy.
     * @param targetPath - Target directory or complete file location to copy
     * to.
     * @param readOptions - Options to use for reading source file.
     * @param writeOptions - Options to use for writing to target file.
     *
     * @returns Determined target file path.
     */
    static copyFileSync(this: void, sourcePath: string, targetPath: string, readOptions?: PlainObject, writeOptions?: PlainObject): string;
    /**
     * Checks if given path points to a valid directory.
     * @param filePath - Path to directory.
     *
     * @returns A promise holding a boolean which indicates directory
     * existence.
     */
    static isDirectory(this: void, filePath: string): Promise<boolean>;
    /**
     * Checks if given path points to a valid directory.
     * @param filePath - Path to directory.
     *
     * @returns A boolean which indicates directory existents.
     */
    static isDirectorySync(this: void, filePath: string): boolean;
    /**
     * Checks if given path points to a valid file.
     * @param filePath - Path to directory.
     *
     * @returns A promise holding a boolean which indicates directory
     * existence.
     */
    static isFile(this: void, filePath: string): Promise<boolean>;
    /**
     * Checks if given path points to a valid file.
     * @param filePath - Path to file.
     *
     * @returns A boolean which indicates file existence.
     */
    static isFileSync(this: void, filePath: string): boolean;
    /**
     * Iterates through given directory structure recursively and calls given
     * callback for each found file. Callback gets file path and corresponding
     * stat object as argument.
     * @param directoryPath - Path to directory structure to traverse.
     * @param callback - Function to invoke for each traversed file and
     * potentially manipulate further traversing in alphabetical sorted order.
     * If it returns "null" or a promise resolving to "null", no further files
     * will be traversed afterwards.
     * If it handles a directory and returns "false" or a promise resolving to
     * "false" no traversing into that directory will occur.
     * @param options - Options to use for nested "readdir" calls.
     *
     * @returns A promise holding the determined files.
     */
    static walkDirectoryRecursively(this: void, directoryPath: string, callback?: null | ((_file: File) => FileTraversionResult), options?: Encoding | SecondParameter<typeof import('fs').readdir>): Promise<Array<File>>;
    /**
     * Iterates through given directory structure recursively and calls given
     * callback for each found file. Callback gets file path and corresponding
     * stats object as argument.
     * @param directoryPath - Path to directory structure to traverse.
     * @param callback - Function to invoke for each traversed file.
     * @param options - Options to use for nested "readdir" calls.
     *
     * @returns Determined list if all files.
     */
    static walkDirectoryRecursivelySync(this: void, directoryPath: string, callback?: AnyFunction | null, options?: Encoding | SecondParameter<typeof import('fs').readdirSync>): Array<File>;
    /**
     * Generates a one shot close handler which triggers given promise methods.
     * If a reason is provided it will be given as resolve target. An Error
     * will be generated if return code is not zero. The generated Error has
     * a property "returnCode" which provides corresponding process return
     * code.
     * @param resolve - Promise's resolve function.
     * @param reject - Promise's reject function.
     * @param reason - Promise target if process has a zero return code.
     * @param callback - Optional function to call of process has successfully
     * finished.
     *
     * @returns Process close handler function.
     */
    static getProcessCloseHandler(this: void, resolve: ProcessCloseCallback, reject: ProcessErrorCallback, reason?: unknown, callback?: AnyFunction): ProcessHandler;
    /**
     * Forwards given child process communication channels to corresponding
     * current process communication channels.
     * @param childProcess - Child process meta data.
     *
     * @returns Given child process meta data.
     */
    static handleChildProcess(this: void, childProcess: ChildProcess): ChildProcess;
    /**
     * Helper method for attach/remove event handler methods.
     * @param parameters - Arguments object given to methods like "on()" or
     * "off()".
     * @param removeEvent - Indicates if handler should be attached or removed.
     * @param eventFunctionName - Name of function to wrap.
     *
     * @returns Returns $'s wrapped dom node.
     */
    _bindEventHelper: <TElement_1 = HTMLElement>(parameters: Array<unknown>, removeEvent?: boolean, eventFunctionName?: string) => $T<TElement_1>;
}
/**
 * Dom bound version of Tools class.
 */
export declare class BoundTools<TElement = HTMLElement> extends Tools<TElement> {
    $domNode: $T<TElement>;
    readonly self: typeof BoundTools;
    /**
     * This method should be overwritten normally. It is triggered if current
     * object is created via the "new" keyword. The dom node selector prefix
     * enforces to not globally select any dom nodes which aren't in the
     * expected scope of this plugin. "{1}" will be automatically replaced with
     * this plugin name suffix ("tools"). You don't have to use "{1}" but it
     * can help you to write code which is more reconcilable with the dry
     * concept.
     * @param $domNode - $-extended dom node to use as reference in various
     * methods.
     * @param additionalParameters - Additional parameters to call super method
     * with.
     *
     * @returns Nothing.
     */
    constructor($domNode: $T<TElement>, ...additionalParameters: ParametersExceptFirst<Tools['constructor']>);
}
export default Tools;
export declare const augment$: (value: $TStatic) => void;
