import { AnyFunction, FirstParameter, FunctionTestTuple, FunctionTestPromiseTuple, FunctionTestPromiseRejectionTuple, TestMatchers as Matchers, TestSymbol, ThenParameter, UnknownFunction } from './type';
export declare const DefinedSymbol: unique symbol;
export declare const ThrowSymbol: unique symbol;
export declare const UndefinedSymbol: unique symbol;
/**
 * Tests given result against given expectations. Respects special symbol
 * values.
 * @param givenResult - Target to compare expectation against.
 * @param expected - Expected result.
 * @param wrap - Indicates whether to wrap with an expect function call.
 *
 * @returns Nothing.
 */
export declare const testExpectedType: <Type = unknown, Result extends void | Promise<void> = void>(givenResult: Result | Matchers<Result>, expected: Type | TestSymbol, wrap?: boolean) => Result;
/**
 * Tests each given test set (expected value follows by various list of
 * function parameters). It respects function signature to raise compile time
 * errors if given test set does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param functionTestTuple - Additional arrays of test sets to test given
 * function again.
 *
 * @returns Nothing.
 */
export declare const testEach: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, ...functionTestTuple: [ReturnType<FunctionType>, ...Parameters<FunctionType>][]) => void;
/**
 * Tests each given test set (expected value follows by various list of
 * function parameters). It respects function signature to raise compile time
 * errors if given test set does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param functionTestTuple - Additional arrays of test sets to test given
 * function again.
 *
 * @returns Nothing.
 */
export declare const testEachPromise: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, ...functionTestTuple: [ThenParameter<ReturnType<FunctionType>>, ...Parameters<FunctionType>][]) => void;
/**
 * Tests each given test set (expected value follows by various list of
 * function parameters). It respects function signature to raise compile time
 * errors if given test set does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param functionTestTuple - Additional arrays of test sets to test given
 * function again.
 *
 * @returns Nothing.
 */
export declare const testEachPromiseRejection: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, ...functionTestTuple: [Error, ...Parameters<FunctionType>][]) => void;
/**
 * Tests each given single parameter against same given expected value. It
 * respects function signature to raise compile time errors if given test set
 * does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param expected - Value to check each function call return value against.
 * @param parameters - Additional first parameters to test given function with.
 *
 * @returns Nothing.
 */
export declare const testEachSingleParameterAgainstSameExpectation: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, expected: TestSymbol | ReturnType<FunctionType>, ...parameters: FirstParameter<FunctionType>[]) => void;
/**
 * Tests each given single parameter against same given expected value. It
 * respects function signature to raise compile time errors if given test set
 * does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param expected - Value to check each function call return value against.
 * @param parameters - Additional first parameters to test given function with.
 *
 * @returns Nothing.
 */
export declare const testEachSingleParameterAgainstSamePromisedExpectation: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, expected: TestSymbol | ThenParameter<ReturnType<FunctionType>>, ...parameters: FirstParameter<FunctionType>[]) => void;
/**
 * Tests each given single parameter against same given expected value. It
 * respects function signature to raise compile time errors if given test set
 * does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param expected - Value to check each function call return value against.
 * @param parameters - Additional first parameters to test given function with.
 *
 * @returns Nothing.
 */
export declare const testEachSingleParameterAgainstSameRejectedExpectation: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, expected: Error | TestSymbol, ...parameters: FirstParameter<FunctionType>[]) => void;
/**
 * Tests each given test set (various list of function parameters) against same
 * given expected value. It respects function signature to raise compile time
 * errors if given test set does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param expected - Value to check each function call return value against.
 * @param functionParameters - Additional lists of parameters to test given
 * function again.
 *
 * @returns Nothing.
 */
export declare const testEachAgainstSameExpectation: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, expected: TestSymbol | ReturnType<FunctionType>, ...functionParameters: Parameters<FunctionType>[]) => void;
/**
 * Tests each given test set (various list of function parameters) against same
 * given expected value. It respects function signature to raise compile time
 * errors if given test set does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param expected - Value to check each function call return value against.
 * @param functionParameters - Additional lists of parameters to test given
 * function again.
 *
 * @returns Nothing.
 */
export declare const testEachPromiseAgainstSameExpectation: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, expected: TestSymbol | ThenParameter<ReturnType<FunctionType>>, ...functionParameters: Parameters<FunctionType>[]) => void;
/**
 * Tests each given test set (various list of function parameters) against same
 * given expected value. It respects function signature to raise compile time
 * errors if given test set does not match given function signature.
 * @param functionName - Function description to test.
 * @param callback - Function reference to test.
 * @param expected - Value to check each function call return value against.
 * @param functionParameters - Additional lists of parameters to test given
 * function again.
 *
 * @returns Nothing.
 */
export declare const testEachPromiseRejectionAgainstSameExpectation: <FunctionType extends AnyFunction = UnknownFunction>(functionName: string, callback: FunctionType, expected: Error | TestSymbol, ...functionParameters: Parameters<FunctionType>[]) => void;
export default testEach;
